<?php
    date_default_timezone_set("Europe/Amsterdam");

    $time =  date("h:i:sa");
    echo "<h2>$time<h2/>";

    $hour = date("h");

    if ($hour > "6" && $hour <= "12") {
        $background = "morning.png";
        echo "<h2>Goedemorgen!</h2>";
    } if ($hour > "12" && $hour <= "18"){
        $background = "afternoon.png";
        echo "<h2>GoedeMiddag!</h2>"; 
    } if ($hour > "18" && $hour <= "00") {
        $background = "evening.png";
        echo "<h2>GoedeAvond!</h2>";
    } if ($hour > "00" && $hour <= "6") {
        $background = "night.png";
        echo "<h2>GoedeNacht!</h2>";
    };
?>
